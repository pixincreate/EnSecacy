Hello there.,
This is Pavana Narayana Bhat who wrote this script for you.

Thank you for downloading my Script.

Steps to followed to use this script:
	1. Enable Developer Options by going to ABOUT >> SYSTEM >> Click the BUILD NUMBER 7 times (Universally) incase of MIUI, Click MIUI VERSION 7 times.
	2. Enable USB Debugging
	3. Run the EnSecacy.exe script within this folder itself, else it will not work.
	Everything else has been elaborated in detail.

About EnSecacy:
	EnSecacy's expansion is Enhanced Security and Privacy. Although it's not "really" enhanced, this script will help you in getting out of trackers and Ads that can be seen on
	Xiaomi Phones. By using this script, I  BET, YOU'LL BE SATISFIED after executing my script EnSecacy.
	Battery Optimise might not Work on Xiaomi phone I think. Because, I waited for more than 10 minutes which didn't prompted "success" when experimented on Redmi Note 7s.
		I hope it work for you atleast.

About Me:
	I'm Pavana Narayana Bhat, a coder, and a YouTuber running PiXinCreate on YouTube. 
	I make videos related to Photo editing where I teach my fellow viewers to edit photos on their own to the extinct I know. 
	I'm a Privacy Centered tech enthusiast.
	You can find me on: Instagram, Facebook, YouTube, Twitter
			@pixincreate is the userName. See you there.:)



© PiXinCreate
All rigths reserved.

ChangeLogs:
	v1: 	Initial Release.

	v2: 	Fixed Exit Option which was not working.
		Added Refresh Rate Config.(It may/may_not WORK.) You cannot expect more from it.
	
	v3: 	UI changes.
		